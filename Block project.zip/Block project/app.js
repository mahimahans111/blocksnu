var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/ngo_s", { useNewUrlParser: true });

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");

//schema
var ngoSchema = new mongoose.Schema({
  name: String,
  websiteLink: String
});

var NGO = mongoose.model("NGO", ngoSchema);

// NGO.create(
//   {
//     name:"SAMMAAN FOUNDATION",
//     websiteLink:"http://sammaan.org/"
//   }, function(err, NGO){
//     if(err){
//       console.log(err);
//     } else{
//       console.log("listed NGO");
//       console.log(NGO);
//     }
// });

var ngos = [
  {name:"SAMMAAN FOUNDATION", websiteLink:"http://sammaan.org/"},
  {name:"GOONJ", websiteLink:"https://goonj.org/"},
  {name:"AKSHAYA TRUST", websiteLink:"http://www.akshayatrust.org/"},
  {name:"SMILE FOUNDATION", websiteLink:"https://www.smilefoundationindia.org/"},
  {name:"UDAAN WELFARE FOUNDATION",websiteLink:"http://www.udaanwelfare.org/"}
];

app.get("/", function(req,res){
  res.render("landing.ejs");
});

app.get("/volunteer", function(req,res){
  res.render("volunteer.ejs");
});

app.get("/ngos", function(req,res){
  NGO.find({}, function(err, allngos){
    if(err){
      console.log(err);
    }
    else{
      res.render("ngos.ejs", {ngos:allngos});
    }
  });
  // res.render("ngos.ejs", {ngos:ngos});
});

app.get("/pay", function(req,res){
  res.render("pay.ejs");
});

// app.listen(process.env.PORT, process.env.IP, function(){
//   console.log("Here we go!");
// });
 app.set('port', process.env.PORT || 3000);
 app.listen(3000, function(){
   console.log("the server has started");
 });
