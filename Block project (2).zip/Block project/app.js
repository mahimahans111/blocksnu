var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/ngo_s", { useNewUrlParser: true });

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");

//schema
var ngoSchema = new mongoose.Schema({
  name: String,
  currentBal: Number
});

var formSchema = new mongoose.Schema({
  name:String,
  email:String,
  phone:String,
  why:String,
  time:String
});

var NGO = mongoose.model("NGO", ngoSchema);

var form = mongoose.model("form",formSchema);

// NGO.create(
//   {
//     name:"LET THEM FLY",
//     currentBal:5000
//   }, function(err, NGO){
//     if(err){
//       console.log(err);
//     } else{
//       console.log("listed NGO");
//       console.log(NGO);
//     }
// });

var ngos = [
  {name:"SAMMAAN FOUNDATION",currentBal:10000},
  {name:"GOONJ", currentBal:8000},
  {name:"AKSHAYA TRUST", currentBal:5000},
  {name:"SMILE FOUNDATION", currentBal:9856},
  {name:"UDAAN WELFARE FOUNDATION",currentBal:11000}
];

app.get("/", function(req,res){
  res.render("landing.ejs");
});

app.get("/volunteer", function(req,res){
  res.render("volunteer.ejs");
});

app.get("/ngos", function(req,res){
  NGO.find({}, function(err, allngos){
    if(err){
      console.log(err);
    }
    else{
      res.render("ngos.ejs", {ngos:allngos});
    }
  });
});

app.get("/:ngoname/transactions", function(req,res){
  res.render("index.ejs",{
    name:req.params.ngoname
  });
});

app.get("/pay", function(req,res){
  res.render("pay.ejs");
});

app.post("/details", function(req,res){
  var name = req.body.name;
  var email = req.body.email;
  var phone = req.body.phone;
  var why = req.body.why;
  var time = req.body.time;
  var newForm = {
    name:name,
    email:email,
    phone:phone,
    why:why,
    time:time
  }
  form.create(newForm, function(err, newForm){
    if(err){
      console.log(err);
    }
    else{
      res.redirect("/");
    }
  })

})

 app.set('port', process.env.PORT || 3000);
 app.listen(3000, function(){
   console.log("the server has started");
 });

app.post
